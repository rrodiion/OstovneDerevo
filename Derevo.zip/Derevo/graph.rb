class Graph
  def initialize(vertices)
    @vertices = vertices
    @graph = Array.new(vertices) { Array.new(vertices, 0) } #Створюємо матрицю суміжності графа
  end

  def add_edge(source, destination, weight)
    @graph[source][destination] = weight #Додаємо ребро між вершинами source та destination з вагою weight
    @graph[destination][source] = weight #Граф без конкретного напрямку, тому додаємо ребро у обидва напрямки
  end

  def prim_mst
    key = [] #Ваги вершин, які будуть обрані у остовне дерево
    mst_set = [] #Вершини, які вже включені в остовне дерево
    parent = [] #Батьківські вершини для знаходження остовного дерева

    @vertices.times do |v|
      key[v] = Float::INFINITY #Ініціалізуємо всі ваги як нескінченні
      mst_set[v] = false #Жодна вершина ще не включена в остовне дерево
    end

    key[0] = 0 #Почнемо з першої вершини
    parent[0] = -1

    (@vertices - 1).times do
      u = min_key(key, mst_set) #Знаходимо вершину з найменшою вагою
      mst_set[u] = true

      (0...@vertices).each do |v|
        if @graph[u][v] > 0 && !mst_set[v] && @graph[u][v] < key[v]
          parent[v] = u #Встановлюємо батьківську вершину та вагу
          key[v] = @graph[u][v]
        end
      end
    end

    print_mst(parent) #Результат
  end

  private

  def min_key(key, mst_set)
    min = Float::INFINITY
    min_index = -1

    @vertices.times do |v|
      if !mst_set[v] && key[v] < min
        min = key[v] #Знаходимо вершину з найменшою вагою, яка ще не включена в остовне дерево
        min_index = v
      end
    end

    min_index
  end

  def print_mst(parent)
    puts "Ребро \t Вага"
    (1...@vertices).each do |i|
      puts "#{parent[i]} - #{i} \t #{@graph[i][parent[i]]}" #Виводимо знайдені ребра та їх вагу
    end
  end
end


g = Graph.new(5)
g.add_edge(0, 1, 2)
g.add_edge(0, 3, 6)
g.add_edge(1, 2, 3)
g.add_edge(1, 3, 8)
g.add_edge(1, 4, 5)
g.add_edge(2, 4, 7)
g.add_edge(3, 4, 9)

g.prim_mst #Запускаємо алгоритм для знаходження остовного дерева
